/**
 * telegram.js
 * Thin wrapper around the Telegram WebApp API.
 * Safe to run outside Telegram (e.g. plain browser) — all calls are guarded.
 */

const BooklyTelegram = (function () {
  const tg = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;

  function init() {
    if (!tg) return;
    tg.ready();
    tg.expand();
    applyThemeParams();
    tg.onEvent('themeChanged', applyThemeParams);
  }

  /**
   * Maps Telegram's theme colors onto our CSS variables so the app
   * blends into the native Telegram chrome when opened as a Mini App.
   */
  function applyThemeParams() {
    if (!tg || !tg.themeParams) return;
    const p = tg.themeParams;
    const root = document.documentElement;

    if (p.bg_color) root.style.setProperty('--tg-bg', p.bg_color);
    if (p.text_color) root.style.setProperty('--tg-text', p.text_color);
    if (p.hint_color) root.style.setProperty('--tg-hint', p.hint_color);
    if (p.button_color) root.style.setProperty('--tg-button', p.button_color);
    if (p.button_text_color) root.style.setProperty('--tg-button-text', p.button_text_color);
    if (p.secondary_bg_color) root.style.setProperty('--tg-secondary-bg', p.secondary_bg_color);

    // Follow Telegram's own light/dark signal for our app theme.
    if (tg.colorScheme) {
      document.body.setAttribute('data-mode', tg.colorScheme === 'dark' ? 'dark' : 'light');
    }
  }

  function isTelegram() {
    return !!tg;
  }

  function hapticImpact(style) {
    if (tg && tg.HapticFeedback) {
      try {
        tg.HapticFeedback.impactOccurred(style || 'light');
      } catch (e) {
        /* no-op */
      }
    }
  }

  function showBackButton(onClick) {
    if (!tg || !tg.BackButton) return;
    tg.BackButton.show();
    tg.BackButton.onClick(onClick);
  }

  function hideBackButton() {
    if (!tg || !tg.BackButton) return;
    tg.BackButton.hide();
  }

  return { init, isTelegram, hapticImpact, showBackButton, hideBackButton };
})();

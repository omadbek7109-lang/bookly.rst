/**
 * preview.js
 * Renders a book in a realistic "reader" layout: cover -> title -> author
 * -> contents -> chapter -> text/images -> audio, with prev/next navigation.
 */

const BooklyPreview = (function () {
  let currentBook = null;
  let currentChapterIndex = 0; // -1 means "cover / contents" screen

  function open(bookId) {
    currentBook = getBookById(bookId);
    if (!currentBook) return;
    currentChapterIndex = -1;
    render();
    BooklyApp.showView('preview');
  }

  function render() {
    const root = document.getElementById('preview-root');
    if (!root || !currentBook) return;

    root.className = `reader theme-${currentBook.theme || 'classic'}`;

    if (currentChapterIndex === -1) {
      root.innerHTML = renderCoverScreen(currentBook);
    } else {
      root.innerHTML = renderChapterScreen(currentBook, currentChapterIndex);
    }

    wireAudio();
    wireNav();
  }

  function renderCoverScreen(book) {
    const coverImg = book.cover
      ? `<img src="${book.cover}" alt="Muqova" class="reader-cover-img" />`
      : `<div class="reader-cover-placeholder">📕</div>`;

    const contentsList = (book.chapters || [])
      .map(
        (ch, i) =>
          `<li><button class="reader-contents-item" data-chapter-index="${i}">${escapeHtml(ch.title || 'Bob')}</button></li>`
      )
      .join('');

    return `
      <div class="reader-cover">
        ${coverImg}
        <h1 class="reader-title">${escapeHtml(book.title || 'Nomsiz kitob')}</h1>
        ${book.author ? `<p class="reader-author">${escapeHtml(book.author)}</p>` : ''}
        ${book.description ? `<p class="reader-desc">${escapeHtml(book.description)}</p>` : ''}
        <h2 class="reader-contents-title">Mundarija</h2>
        <ul class="reader-contents-list">${contentsList}</ul>
        ${renderAudioPlayer(book)}
      </div>
    `;
  }

  function renderChapterScreen(book, index) {
    const chapter = book.chapters[index];
    if (!chapter) return '<p>Bob topilmadi.</p>';

    const blocksHtml = (chapter.blocks || []).map(renderBlock).join('') || `<p class="reader-empty">Bu bob hali bo‘sh.</p>`;

    const isFirst = index === 0;
    const isLast = index === book.chapters.length - 1;

    return `
      <div class="reader-chapter">
        <button class="reader-back-link" data-go-cover="1">‹ Mundarija</button>
        <h2 class="reader-chapter-title">${escapeHtml(chapter.title || 'Bob')}</h2>
        <div class="reader-chapter-body">${blocksHtml}</div>
        ${renderAudioPlayer(book)}
        <div class="reader-nav">
          <button class="btn btn-ghost" data-prev="1" ${isFirst ? 'disabled' : ''}>‹ Oldingi</button>
          <span class="reader-nav-count">${index + 1} / ${book.chapters.length}</span>
          <button class="btn btn-ghost" data-next="1" ${isLast ? 'disabled' : ''}>Keyingi ›</button>
        </div>
      </div>
    `;
  }

  function renderBlock(block) {
    switch (block.type) {
      case 'heading':
        return `<h3 class="reader-block-heading">${escapeHtml(block.content || '')}</h3>`;
      case 'quote':
        return `<blockquote class="reader-block-quote">${block.content || ''}</blockquote>`;
      case 'divider':
        return `<hr class="reader-block-divider" />`;
      case 'image':
        return block.content ? `<img class="reader-block-image" src="${block.content}" alt="" />` : '';
      default:
        return `<div class="reader-block-text">${block.content || ''}</div>`;
    }
  }

  function renderAudioPlayer(book) {
    if (!book.audio || !book.audio.src) return '';
    return `
      <div class="reader-audio">
        <div class="reader-audio-name">🎵 ${escapeHtml(book.audio.name || 'Audio')}</div>
        <audio id="reader-audio-el" src="${book.audio.src}" preload="none"></audio>
        <div class="reader-audio-controls">
          <button class="btn btn-icon" id="reader-audio-toggle">▶️</button>
          <input type="range" id="reader-audio-volume" min="0" max="1" step="0.05" value="1" />
        </div>
      </div>
    `;
  }

  function wireAudio() {
    const audioEl = document.getElementById('reader-audio-el');
    const toggleBtn = document.getElementById('reader-audio-toggle');
    const volumeEl = document.getElementById('reader-audio-volume');
    if (!audioEl || !toggleBtn) return;

    toggleBtn.addEventListener('click', () => {
      if (audioEl.paused) {
        audioEl.play();
        toggleBtn.textContent = '⏸️';
      } else {
        audioEl.pause();
        toggleBtn.textContent = '▶️';
      }
    });
    audioEl.addEventListener('ended', () => {
      toggleBtn.textContent = '▶️';
    });
    if (volumeEl) {
      volumeEl.addEventListener('input', () => {
        audioEl.volume = parseFloat(volumeEl.value);
      });
    }
  }

  function wireNav() {
    const root = document.getElementById('preview-root');
    root.querySelectorAll('[data-chapter-index]').forEach((btn) => {
      btn.addEventListener('click', () => {
        currentChapterIndex = parseInt(btn.dataset.chapterIndex, 10);
        render();
      });
    });
    const backLink = root.querySelector('[data-go-cover]');
    if (backLink) backLink.addEventListener('click', () => {
      currentChapterIndex = -1;
      render();
    });
    const prevBtn = root.querySelector('[data-prev]');
    if (prevBtn) prevBtn.addEventListener('click', () => {
      if (currentChapterIndex > 0) {
        currentChapterIndex -= 1;
        render();
      }
    });
    const nextBtn = root.querySelector('[data-next]');
    if (nextBtn) nextBtn.addEventListener('click', () => {
      if (currentChapterIndex < currentBook.chapters.length - 1) {
        currentChapterIndex += 1;
        render();
      }
    });
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function getCurrentBook() {
    return currentBook;
  }

  return { open, getCurrentBook };
})();

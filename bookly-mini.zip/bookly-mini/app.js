/**
 * app.js
 * App shell: view routing, bottom navigation, dashboard (book cards),
 * "new book" flow, and the settings screen (light/dark mode).
 */

const BooklyApp = (function () {
  const VIEWS = ['dashboard', 'editor', 'preview', 'settings'];
  let newBookDraft = null;

  function init() {
    BooklyTelegram.init();
    applySavedMode();
    wireBottomNav();
    wireDashboard();
    wireNewBookModal();
    wireEditorChrome();
    wireSettings();
    renderDashboard();
    showView('dashboard');
  }

  // ---------- View routing ----------

  function showView(name) {
    VIEWS.forEach((v) => {
      const el = document.getElementById(`view-${v}`);
      if (el) el.classList.toggle('hidden', v !== name);
    });
    document.querySelectorAll('.nav-btn').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.nav === name);
    });
    // Bottom nav only makes sense for top-level views.
    const bottomNav = document.getElementById('bottom-nav');
    bottomNav.classList.toggle('hidden', name === 'editor' || name === 'preview');

    if (name === 'dashboard') renderDashboard();
  }

  function wireBottomNav() {
    document.querySelectorAll('.nav-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        BooklyTelegram.hapticImpact('light');
        showView(btn.dataset.nav);
      });
    });
  }

  // ---------- Dashboard ----------

  function renderDashboard() {
    const grid = document.getElementById('book-grid');
    const empty = document.getElementById('dashboard-empty');
    const books = getAllBooks();

    if (!books.length) {
      grid.innerHTML = '';
      empty.classList.remove('hidden');
      return;
    }
    empty.classList.add('hidden');

    grid.innerHTML = books
      .map(
        (b) => `
        <div class="book-card">
          <div class="book-card-cover">
            ${b.cover ? `<img src="${b.cover}" alt="" />` : `<span>📕</span>`}
          </div>
          <div class="book-card-body">
            <h3 class="book-card-title">${escapeHtml(b.title || 'Nomsiz kitob')}</h3>
            <p class="book-card-author">${escapeHtml(b.author || 'Muallif ko‘rsatilmagan')}</p>
            <p class="book-card-date">Tahrirlangan: ${formatDate(b.updatedAt)}</p>
            <div class="book-card-actions">
              <button class="btn btn-small" data-edit="${b.id}">Tahrirlash</button>
              <button class="btn btn-small btn-ghost" data-preview="${b.id}">Ko‘rish</button>
              <button class="btn btn-small btn-ghost" data-dup="${b.id}">Nusxa</button>
              <button class="btn btn-small btn-danger" data-del="${b.id}">O‘chirish</button>
            </div>
          </div>
        </div>`
      )
      .join('');

    grid.querySelectorAll('[data-edit]').forEach((btn) =>
      btn.addEventListener('click', () => BooklyEditor.open(btn.dataset.edit))
    );
    grid.querySelectorAll('[data-preview]').forEach((btn) =>
      btn.addEventListener('click', () => BooklyPreview.open(btn.dataset.preview))
    );
    grid.querySelectorAll('[data-dup]').forEach((btn) =>
      btn.addEventListener('click', () => {
        duplicateBook(btn.dataset.dup);
        renderDashboard();
      })
    );
    grid.querySelectorAll('[data-del]').forEach((btn) =>
      btn.addEventListener('click', () => {
        if (confirm('Ushbu kitobni butunlay o‘chirmoqchimisiz?')) {
          deleteBook(btn.dataset.del);
          renderDashboard();
        }
      })
    );
  }

  function wireDashboard() {
    document.getElementById('btn-new-book').addEventListener('click', openNewBookModal);
    document.getElementById('btn-new-book-empty').addEventListener('click', openNewBookModal);
  }

  // ---------- New book modal ----------

  function wireNewBookModal() {
    const modal = document.getElementById('new-book-modal');
    document.getElementById('new-book-close').addEventListener('click', closeNewBookModal);
    document.getElementById('new-book-cancel').addEventListener('click', closeNewBookModal);

    document.getElementById('new-book-cover-input').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const dataUrl = await fileToDataUrl(file);
      newBookDraft.cover = dataUrl;
      document.getElementById('new-book-cover-preview').innerHTML = `<img src="${dataUrl}" />`;
    });

    document.querySelectorAll('#new-book-modal [data-theme-pick]').forEach((btn) => {
      btn.addEventListener('click', () => {
        newBookDraft.theme = btn.dataset.themePick;
        document
          .querySelectorAll('#new-book-modal [data-theme-pick]')
          .forEach((b) => b.classList.toggle('active', b === btn));
      });
    });

    document.getElementById('new-book-form').addEventListener('submit', (e) => {
      e.preventDefault();
      newBookDraft.title = document.getElementById('new-book-title').value.trim() || 'Nomsiz kitob';
      newBookDraft.author = document.getElementById('new-book-author').value.trim();
      newBookDraft.description = document.getElementById('new-book-desc').value.trim();
      const created = upsertBook(newBookDraft);
      closeNewBookModal();
      BooklyEditor.open(created.id);
    });

    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeNewBookModal();
    });
  }

  function openNewBookModal() {
    newBookDraft = createEmptyBook();
    document.getElementById('new-book-title').value = '';
    document.getElementById('new-book-author').value = '';
    document.getElementById('new-book-desc').value = '';
    document.getElementById('new-book-cover-preview').innerHTML = '';
    document.querySelectorAll('#new-book-modal [data-theme-pick]').forEach((b, i) =>
      b.classList.toggle('active', i === 0)
    );
    document.getElementById('new-book-modal').classList.remove('hidden');
    BooklyTelegram.hapticImpact('light');
  }

  function closeNewBookModal() {
    document.getElementById('new-book-modal').classList.add('hidden');
  }

  // ---------- Editor chrome (top bar, add-block buttons, theme/audio controls) ----------

  function wireEditorChrome() {
    document.getElementById('editor-back').addEventListener('click', () => showView('dashboard'));

    document.getElementById('editor-book-title').addEventListener('input', (e) => {
      BooklyEditor.setBookTitle(e.target.value);
    });

    document.getElementById('editor-add-chapter').addEventListener('click', () => BooklyEditor.addChapter());

    document.querySelectorAll('[data-add-block]').forEach((btn) => {
      btn.addEventListener('click', () => BooklyEditor.addBlock(btn.dataset.addBlock));
    });

    document.querySelectorAll('[data-theme-choice]').forEach((btn) => {
      btn.addEventListener('click', () => BooklyEditor.setTheme(btn.dataset.themeChoice));
    });

    document.getElementById('editor-audio-input').addEventListener('change', (e) => {
      BooklyEditor.setAudio(e.target.files[0]);
    });
    document.getElementById('editor-audio-remove').addEventListener('click', () => BooklyEditor.removeAudio());

    document.getElementById('editor-preview-btn').addEventListener('click', () => {
      const book = BooklyEditor.getBook();
      if (book) BooklyPreview.open(book.id);
    });

    document.getElementById('editor-export-btn').addEventListener('click', () => {
      const book = BooklyEditor.getBook();
      if (book) BooklyExport.exportToPdf(book);
    });

    document.getElementById('preview-back').addEventListener('click', () => {
      const book = BooklyPreview.getCurrentBook();
      showView(book ? 'editor' : 'dashboard');
      if (book) BooklyEditor.open(book.id);
    });

    document.getElementById('preview-export-btn').addEventListener('click', () => {
      const book = BooklyPreview.getCurrentBook();
      if (book) BooklyExport.exportToPdf(book);
    });
  }

  // ---------- Settings ----------

  function wireSettings() {
    document.querySelectorAll('[data-mode-choice]').forEach((btn) => {
      btn.addEventListener('click', () => {
        setMode(btn.dataset.modeChoice);
      });
    });
  }

  function applySavedMode() {
    const saved = localStorage.getItem('bookly_mode') || 'light';
    setMode(saved, /*skipSave*/ true);
  }

  function setMode(mode, skipSave) {
    document.body.setAttribute('data-mode', mode);
    if (!skipSave) localStorage.setItem('bookly_mode', mode);
    document.querySelectorAll('[data-mode-choice]').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.modeChoice === mode);
    });
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  }

  return { init, showView };
})();

document.addEventListener('DOMContentLoaded', BooklyApp.init);

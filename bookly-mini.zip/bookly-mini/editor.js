/**
 * editor.js
 * The book editor screen: manage chapters, edit block content (text, image,
 * quote, divider), pick a theme, attach audio, and jump into preview.
 */

const BooklyEditor = (function () {
  let book = null;
  let activeChapterId = null;

  function open(bookId) {
    book = getBookById(bookId);
    if (!book) return;
    activeChapterId = book.chapters[0] ? book.chapters[0].id : null;
    render();
    BooklyApp.showView('editor');
  }

  function getActiveChapter() {
    return book.chapters.find((c) => c.id === activeChapterId) || null;
  }

  function persist() {
    upsertBook(book);
  }

  function render() {
    renderHeader();
    renderChapterList();
    renderChapterBody();
    renderSideControls();
  }

  function renderHeader() {
    const titleEl = document.getElementById('editor-book-title');
    if (titleEl) titleEl.value = book.title;
  }

  function renderChapterList() {
    const list = document.getElementById('editor-chapter-list');
    if (!list) return;
    list.innerHTML = book.chapters
      .map(
        (ch, i) => `
        <li class="chapter-item ${ch.id === activeChapterId ? 'active' : ''}" data-chapter-id="${ch.id}">
          <span class="chapter-item-num">${i + 1}.</span>
          <span class="chapter-item-title">${escapeHtml(ch.title || 'Bob')}</span>
          <button class="chapter-item-del" data-del-chapter="${ch.id}" title="O‘chirish">✕</button>
        </li>`
      )
      .join('');

    list.querySelectorAll('.chapter-item').forEach((li) => {
      li.addEventListener('click', (e) => {
        if (e.target.closest('[data-del-chapter]')) return;
        activeChapterId = li.dataset.chapterId;
        render();
      });
    });
    list.querySelectorAll('[data-del-chapter]').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (book.chapters.length <= 1) {
          alert('Kamida bitta bob bo‘lishi kerak.');
          return;
        }
        if (!confirm('Ushbu bobni o‘chirmoqchimisiz?')) return;
        const id = btn.dataset.delChapter;
        book.chapters = book.chapters.filter((c) => c.id !== id);
        if (activeChapterId === id) activeChapterId = book.chapters[0].id;
        persist();
        render();
      });
    });
  }

  function renderChapterBody() {
    const chapter = getActiveChapter();
    const container = document.getElementById('editor-blocks');
    const chapterTitleInput = document.getElementById('editor-chapter-title');
    if (!container || !chapter) return;

    chapterTitleInput.value = chapter.title;
    chapterTitleInput.oninput = () => {
      chapter.title = chapterTitleInput.value;
      persist();
      renderChapterList();
    };

    container.innerHTML = chapter.blocks.map((b) => renderBlockEditor(b)).join('') ||
      `<p class="editor-empty-hint">Quyidagi tugmalar orqali kontent qo‘shing.</p>`;

    wireBlockEvents(chapter);
  }

  function renderBlockEditor(block) {
    switch (block.type) {
      case 'heading':
        return `
          <div class="block-wrap" data-block-id="${block.id}">
            <input class="block-heading-input" data-field="content" value="${escapeAttr(block.content)}" placeholder="Sarlavha..." />
            ${blockToolbar(block.id)}
          </div>`;
      case 'quote':
        return `
          <div class="block-wrap" data-block-id="${block.id}">
            <div class="block-quote-input" contenteditable="true" data-field="content">${block.content || ''}</div>
            ${blockToolbar(block.id)}
          </div>`;
      case 'divider':
        return `
          <div class="block-wrap" data-block-id="${block.id}">
            <hr class="block-divider-preview" />
            ${blockToolbar(block.id)}
          </div>`;
      case 'image':
        return `
          <div class="block-wrap" data-block-id="${block.id}">
            ${block.content ? `<img class="block-image-preview" src="${block.content}" />` : `<label class="block-image-upload">🖼️ Rasm tanlash<input type="file" accept="image/*" data-field="image-file" hidden /></label>`}
            ${blockToolbar(block.id)}
          </div>`;
      default: // text
        return `
          <div class="block-wrap" data-block-id="${block.id}">
            <div class="block-text-toolbar">
              <button data-cmd="bold" title="Qalin"><b>B</b></button>
              <button data-cmd="italic" title="Qiyshiq"><i>I</i></button>
              <button data-cmd="underline" title="Tagchizilgan"><u>U</u></button>
              <button data-cmd="insertUnorderedList" title="Ro‘yxat">• List</button>
              <button data-cmd="justifyLeft" title="Chapga">⇤</button>
              <button data-cmd="justifyCenter" title="Markazga">↔</button>
              <button data-cmd="justifyRight" title="O‘ngga">⇥</button>
            </div>
            <div class="block-text-input" contenteditable="true" data-field="content">${block.content || ''}</div>
            ${blockToolbar(block.id)}
          </div>`;
    }
  }

  function blockToolbar(blockId) {
    return `
      <div class="block-actions">
        <button data-move-up="${blockId}" title="Yuqoriga">↑</button>
        <button data-move-down="${blockId}" title="Pastga">↓</button>
        <button data-del-block="${blockId}" title="O‘chirish">🗑</button>
      </div>`;
  }

  function wireBlockEvents(chapter) {
    const container = document.getElementById('editor-blocks');

    // Text/heading/quote content edits
    container.querySelectorAll('[data-field="content"]').forEach((el) => {
      const blockId = el.closest('.block-wrap').dataset.blockId;
      const eventName = el.tagName === 'INPUT' ? 'input' : 'input';
      el.addEventListener(eventName, () => {
        const block = chapter.blocks.find((b) => b.id === blockId);
        if (!block) return;
        block.content = el.tagName === 'INPUT' ? el.value : el.innerHTML;
        persist();
      });
    });

    // Rich text formatting buttons
    container.querySelectorAll('[data-cmd]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const wrap = btn.closest('.block-wrap');
        const editable = wrap.querySelector('.block-text-input');
        editable.focus();
        document.execCommand(btn.dataset.cmd, false, null);
        const blockId = wrap.dataset.blockId;
        const block = chapter.blocks.find((b) => b.id === blockId);
        if (block) {
          block.content = editable.innerHTML;
          persist();
        }
      });
    });

    // Image upload
    container.querySelectorAll('[data-field="image-file"]').forEach((input) => {
      input.addEventListener('change', async () => {
        const file = input.files[0];
        if (!file) return;
        const blockId = input.closest('.block-wrap').dataset.blockId;
        const block = chapter.blocks.find((b) => b.id === blockId);
        try {
          block.content = await fileToDataUrl(file);
          persist();
          renderChapterBody();
        } catch (err) {
          alert('Rasmni yuklab bo‘lmadi.');
        }
      });
    });

    // Move up/down
    container.querySelectorAll('[data-move-up]').forEach((btn) => {
      btn.addEventListener('click', () => moveBlock(chapter, btn.dataset.moveUp, -1));
    });
    container.querySelectorAll('[data-move-down]').forEach((btn) => {
      btn.addEventListener('click', () => moveBlock(chapter, btn.dataset.moveDown, 1));
    });

    // Delete
    container.querySelectorAll('[data-del-block]').forEach((btn) => {
      btn.addEventListener('click', () => {
        chapter.blocks = chapter.blocks.filter((b) => b.id !== btn.dataset.delBlock);
        persist();
        renderChapterBody();
      });
    });
  }

  function moveBlock(chapter, blockId, direction) {
    const idx = chapter.blocks.findIndex((b) => b.id === blockId);
    const newIdx = idx + direction;
    if (idx === -1 || newIdx < 0 || newIdx >= chapter.blocks.length) return;
    const [item] = chapter.blocks.splice(idx, 1);
    chapter.blocks.splice(newIdx, 0, item);
    persist();
    renderChapterBody();
  }

  function addBlock(type) {
    const chapter = getActiveChapter();
    if (!chapter) return;
    chapter.blocks.push({ id: generateId(), type, content: '' });
    persist();
    renderChapterBody();
  }

  function addChapter() {
    const newChapter = { id: generateId(), title: `Bob ${book.chapters.length + 1}`, blocks: [] };
    book.chapters.push(newChapter);
    activeChapterId = newChapter.id;
    persist();
    render();
  }

  function renderSideControls() {
    // Theme buttons
    document.querySelectorAll('[data-theme-choice]').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.themeChoice === book.theme);
    });

    // Audio
    const audioNameEl = document.getElementById('editor-audio-name');
    if (audioNameEl) audioNameEl.textContent = book.audio ? book.audio.name : 'Audio biriktirilmagan';

    const audioPreview = document.getElementById('editor-audio-preview');
    if (audioPreview) {
      audioPreview.innerHTML = book.audio
        ? `<audio controls src="${book.audio.src}" style="width:100%"></audio>`
        : '';
    }
  }

  function setTheme(theme) {
    book.theme = theme;
    persist();
    renderSideControls();
  }

  async function setAudio(file) {
    if (!file) return;
    try {
      const src = await fileToDataUrl(file);
      book.audio = { name: file.name, src };
      persist();
      renderSideControls();
    } catch (err) {
      alert('Audio faylni yuklab bo‘lmadi.');
    }
  }

  function removeAudio() {
    book.audio = null;
    persist();
    renderSideControls();
  }

  function setBookTitle(value) {
    book.title = value;
    persist();
  }

  function getBook() {
    return book;
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  }
  function escapeAttr(str) {
    return (str || '').replace(/"/g, '&quot;');
  }

  return {
    open,
    addBlock,
    addChapter,
    setTheme,
    setAudio,
    removeAudio,
    setBookTitle,
    getBook
  };
})();

/**
 * export.js
 * Turns a book into a downloadable PDF using html2pdf.js (loaded from CDN in index.html).
 * Builds a clean, print-friendly DOM off-screen, then hands it to html2pdf.
 */

const BooklyExport = (function () {
  function buildPrintableHtml(book) {
    const wrapper = document.createElement('div');
    wrapper.style.fontFamily = "'Lora', serif";
    wrapper.style.color = '#1f1b16';
    wrapper.style.padding = '32px';

    // Cover
    const cover = document.createElement('div');
    cover.style.textAlign = 'center';
    cover.style.marginBottom = '48px';
    if (book.cover) {
      const img = document.createElement('img');
      img.src = book.cover;
      img.style.maxWidth = '60%';
      img.style.borderRadius = '8px';
      img.style.marginBottom = '24px';
      cover.appendChild(img);
    }
    const title = document.createElement('h1');
    title.textContent = book.title || 'Nomsiz kitob';
    title.style.fontSize = '28px';
    title.style.margin = '0 0 8px';
    cover.appendChild(title);
    if (book.author) {
      const author = document.createElement('p');
      author.textContent = book.author;
      author.style.color = '#6b6257';
      cover.appendChild(author);
    }
    wrapper.appendChild(cover);

    // Chapters
    (book.chapters || []).forEach((ch) => {
      const chapterEl = document.createElement('div');
      chapterEl.style.marginBottom = '40px';
      chapterEl.style.pageBreakBefore = 'always';

      const chTitle = document.createElement('h2');
      chTitle.textContent = ch.title || 'Bob';
      chTitle.style.fontSize = '20px';
      chTitle.style.borderBottom = '1px solid #e5ddcb';
      chTitle.style.paddingBottom = '8px';
      chapterEl.appendChild(chTitle);

      (ch.blocks || []).forEach((block) => {
        chapterEl.appendChild(renderBlockForPrint(block));
      });

      wrapper.appendChild(chapterEl);
    });

    return wrapper;
  }

  function renderBlockForPrint(block) {
    const el = document.createElement('div');
    el.style.marginBottom = '16px';
    el.style.lineHeight = '1.7';

    switch (block.type) {
      case 'heading': {
        const h = document.createElement('h3');
        h.textContent = block.content || '';
        h.style.fontSize = '17px';
        el.appendChild(h);
        break;
      }
      case 'quote': {
        const q = document.createElement('blockquote');
        q.innerHTML = block.content || '';
        q.style.borderLeft = '3px solid #2f6f5e';
        q.style.margin = '0';
        q.style.padding = '4px 16px';
        q.style.fontStyle = 'italic';
        q.style.color = '#4a453c';
        el.appendChild(q);
        break;
      }
      case 'divider': {
        const hr = document.createElement('hr');
        hr.style.border = 'none';
        hr.style.borderTop = '1px solid #e5ddcb';
        hr.style.margin = '24px 0';
        el.appendChild(hr);
        break;
      }
      case 'image': {
        if (block.content) {
          const img = document.createElement('img');
          img.src = block.content;
          img.style.maxWidth = '100%';
          img.style.borderRadius = '6px';
          el.appendChild(img);
        }
        break;
      }
      default: {
        const p = document.createElement('div');
        p.innerHTML = block.content || '';
        p.style.fontSize = '14px';
        el.appendChild(p);
      }
    }
    return el;
  }

  /**
   * Generates and triggers download of the book as a PDF.
   * Requires html2pdf.js to already be loaded on window.
   */
  function exportToPdf(book) {
    if (typeof html2pdf === 'undefined') {
      alert('PDF generatsiya kutubxonasi yuklanmadi. Internet aloqasini tekshiring.');
      return;
    }
    const printable = buildPrintableHtml(book);
    const opt = {
      margin: 10,
      filename: `${(book.title || 'kitob').replace(/[^\w\s-]/g, '')}.pdf`,
      image: { type: 'jpeg', quality: 0.95 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: 'mm', format: 'a5', orientation: 'portrait' }
    };
    html2pdf().set(opt).from(printable).save();
  }

  return { exportToPdf };
})();

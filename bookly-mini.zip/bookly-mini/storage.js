/**
 * storage.js
 * Handles all localStorage persistence for Bookly Mini.
 * Books are stored as a single JSON array under the key "bookly_books".
 */

const STORAGE_KEY = 'bookly_books';

/**
 * Generates a short unique id.
 */
function generateId() {
  return 'b_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
}

/**
 * Returns a brand-new empty book object.
 */
function createEmptyBook() {
  const now = new Date().toISOString();
  return {
    id: generateId(),
    title: 'Nomsiz kitob',
    author: '',
    description: '',
    cover: null, // base64 / object URL string
    theme: 'classic', // classic | modern | dark
    audio: null, // { name, src }
    chapters: [
      {
        id: generateId(),
        title: 'Kirish',
        blocks: []
      }
    ],
    createdAt: now,
    updatedAt: now
  };
}

/**
 * Reads all books from localStorage.
 */
function getAllBooks() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Kitoblarni o‘qishda xatolik:', err);
    return [];
  }
}

/**
 * Persists the full book list.
 */
function saveAllBooks(books) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(books));
    return true;
  } catch (err) {
    console.error('Saqlashda xatolik:', err);
    // Most likely quota exceeded (large base64 images/audio).
    alert('Xotira to‘lgan bo‘lishi mumkin. Rasm yoki audio hajmini kichraytiring.');
    return false;
  }
}

/**
 * Returns a single book by id, or null.
 */
function getBookById(id) {
  return getAllBooks().find((b) => b.id === id) || null;
}

/**
 * Inserts or updates a book (matched by id) and saves.
 */
function upsertBook(book) {
  const books = getAllBooks();
  const idx = books.findIndex((b) => b.id === book.id);
  book.updatedAt = new Date().toISOString();
  if (idx === -1) {
    books.unshift(book);
  } else {
    books[idx] = book;
  }
  saveAllBooks(books);
  return book;
}

/**
 * Deletes a book by id.
 */
function deleteBook(id) {
  const books = getAllBooks().filter((b) => b.id !== id);
  saveAllBooks(books);
}

/**
 * Duplicates a book (new id, "(nusxa)" suffix on title).
 */
function duplicateBook(id) {
  const original = getBookById(id);
  if (!original) return null;
  const copy = JSON.parse(JSON.stringify(original));
  copy.id = generateId();
  copy.title = original.title + ' (nusxa)';
  copy.chapters = copy.chapters.map((ch) => ({ ...ch, id: generateId() }));
  copy.createdAt = new Date().toISOString();
  copy.updatedAt = copy.createdAt;
  const books = getAllBooks();
  books.unshift(copy);
  saveAllBooks(books);
  return copy;
}

/**
 * Reads a File object and returns a base64 data URL (Promise).
 * Used for cover/chapter images and audio demo playback.
 */
function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('Faylni o‘qib bo‘lmadi'));
    reader.readAsDataURL(file);
  });
}

/**
 * Formats an ISO date string into a short, human-readable form (Uzbek).
 */
function formatDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const pad = (n) => String(n).padStart(2, '0');
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

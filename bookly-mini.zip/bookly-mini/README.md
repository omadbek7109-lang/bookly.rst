# 📚 Bookly Mini

Telegram Web Mini App ko‘rinishidagi elektron kitob yaratish platformasi (V1, frontend-only).

Foydalanuvchi bot orqali Web App'ni ochadi, kichik va chiroyli editor orqali o‘z elektron kitobini yaratadi: boblar, matn, rasm, iqtibos, audio, 3 xil dizayn (Classic / Modern / Dark), va PDF eksport.

## Texnologiyalar

- HTML5 / CSS3 / Vanilla JavaScript (framework yo‘q)
- Telegram WebApp API
- `localStorage` — barcha ma'lumotlar shu qurilmada saqlanadi, backend yo‘q
- PDF eksport uchun `html2pdf.js` (CDN)

## Fayl tuzilishi

```
bookly-mini/
├── index.html      — SPA shell, barcha ekranlar
├── style.css        — dizayn tokenlar, layout, reader temalari
├── app.js           — routing, dashboard, yangi kitob modali, sozlamalar
├── editor.js         — bob/blok editori, formatlash, audio/tema
├── preview.js        — reader rejimi (cover → bob → matn → audio)
├── storage.js        — localStorage CRUD
├── telegram.js       — Telegram WebApp integratsiyasi
├── export.js         — PDF generatsiya (html2pdf.js)
└── README.md
```

## Mahalliy sinov

Alohida server shart emas — `index.html` faylini brauzerda oching, yoki:

```bash
npx serve .
# yoki
python3 -m http.server 8080
```

## 1) GitHub repository yaratish

1. github.com → **New repository** → nomi: `bookly-mini` (public bo‘lsin).
2. Loyihani yuklang:

```bash
cd bookly-mini
git init
git add .
git commit -m "Bookly Mini v1"
git branch -M main
git remote add origin https://github.com/<username>/bookly-mini.git
git push -u origin main
```

## 2) Fayllarni upload qilish

Yuqoridagi `git push` barcha fayllarni yuklaydi. Shuningdek, GitHub veb-interfeysida **Add file → Upload files** orqali ham qo‘lda yuklash mumkin.

## 3) GitHub Pages yoqish

1. Repo → **Settings → Pages**.
2. **Source**: `Deploy from a branch`.
3. **Branch**: `main`, papka: `/ (root)` → **Save**.
4. Bir necha daqiqadan so‘ng sayt manzili tayyor bo‘ladi:
   `https://<username>.github.io/bookly-mini/`

## 4) Telegram BotFather orqali Web App ulash

1. Telegram'da [@BotFather](https://t.me/BotFather) bilan suhbat oching (yoki yangi bot yarating: `/newbot`).
2. `/mybots` → botingizni tanlang → **Bot Settings → Menu Button** (yoki **Configure Menu Button**).
3. **Edit Menu Button URL** ni tanlab, GitHub Pages manzilini kiriting:
   `https://<username>.github.io/bookly-mini/`
4. Tugma nomini kiriting, masalan: `📚 Bookly Mini`.
5. Botga o‘tib, menyu tugmasini bosing — Mini App ochiladi.

Ixtiyoriy: `/newapp` orqali alohida **Inline Web App** ham sozlash mumkin — BotFather ko‘rsatmalariga amal qiling, URL sifatida xuddi shu GitHub Pages manzilini bering.

## Keyingi versiyalar uchun rejalar

Kod modular qilib yozilgan, shuning uchun quyidagilarni keyinchalik qo‘shish oson bo‘ladi:

- Backend + login + bulutli saqlash (hozir hammasi `localStorage`'da)
- EPUB eksport (`export.js` ichida alohida funksiya sifatida)
- AI yozuv yordamchisi
- Kitoblarni boshqalar bilan ulashish

## Eslatma

Rasm va audio fayllar `base64` ko‘rinishida `localStorage`'da saqlanadi — brauzerning xotira limiti (odatda ~5–10MB) tufayli juda katta fayllardan saqlaning.
